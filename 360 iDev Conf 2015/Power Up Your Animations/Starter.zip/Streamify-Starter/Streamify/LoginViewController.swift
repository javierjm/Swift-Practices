//
//  LoginViewController.swift
//  Streamify
//
//  Created by Marin Todorov on 8/11/15.
//  Copyright (c) 2015 Underplot ltd. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var fldUsername: UITextField!
    @IBOutlet weak var fldPassword: UITextField!
    
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var imgBackground: UIImageView!
    
    var didAnimateFields = false
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    @IBAction func actionLogin(sender: AnyObject) {
        view.endEditing(true)
        
    }
}

extension LoginViewController: UITextViewDelegate {
    func textFieldDidEndEditing(textField: UITextField) {
        
    }
}

// MARK: - Starter project code
extension LoginViewController: StarterProjectCode {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        skipIfSeen(self, "OnBoardingViewController")
        
        btnLogin.layer.borderColor = UIColor(red: 20/255.0, green: 123/255.0, blue: 195/255.0, alpha: 1.0).CGColor
        btnLogin.layer.cornerRadius = 40
    }
    
    func actionShowOnboarding() {
        self.performSegueWithIdentifier("showOnBoarding", sender: self.btnLogin)
        markAsSeen(self, true)
    }
}
