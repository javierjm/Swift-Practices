//
//  VisualizerViewController.swift
//  Streamify
//
//  Created by Marin Todorov on 8/13/15.
//  Copyright (c) 2015 Underplot ltd. All rights reserved.
//

import UIKit

class VisualizerViewController: UIViewController {

    var leftBar = CALayer()
    var rightBar = CALayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func updateLevels(left: Float, right: Float) {
        
    }
}