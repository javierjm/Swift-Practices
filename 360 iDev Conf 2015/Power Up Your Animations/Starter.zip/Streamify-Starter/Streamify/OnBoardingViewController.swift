//
//  OnBoardingViewController.swift
//  Streamify
//
//  Created by Marin Todorov on 8/11/15.
//  Copyright (c) 2015 Underplot ltd. All rights reserved.
//

import UIKit

private let signupText = "Sign up for free with your email or get our paid subscription for up to 5 family members"
private let signupTextDetails = "Deal valid when subscription pre-paid for 37 months and extra family members aren't interested in music. \n\n If switching from a different music service you will receive a tap on the shoulder"

class OnBoardingViewController: UIViewController {
    
    @IBOutlet var signupView: UIView!
    @IBOutlet var signupDetails: UILabel!

    @IBOutlet var mixView: UIView!
    @IBOutlet var listenView: UIView!
    
    var views: [UIView]!
    
    var selectedView: UIView?
    var deselectCurrentView: (()->())?

    func toggleView(tap: UITapGestureRecognizer) {
        selectedView = tap.view!
        
    }
    
    func toggleSignup(tap: UITapGestureRecognizer) {
        if selectedView == tap.view! {
            return
        }
        
        toggleView(tap)

    }
    
    func toggleMix(tap: UITapGestureRecognizer) {
        if selectedView == tap.view! {
            return
        }
        
        toggleView(tap)
        deselectCurrentView = nil
    }
    
    func toggleListen(tap: UITapGestureRecognizer) {
        if selectedView == tap.view! {
            return
        }
        
        toggleView(tap)
        
    }
    
    func actionStartListening(sender: AnyObject) {
        performSegueWithIdentifier("showPlaylists", sender: sender)
    }
}

//MARK: - Starter project code
extension OnBoardingViewController: StarterProjectCode {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        skipIfSeen(self, "PlaylistsViewController")
        
        views = [signupView, mixView, listenView]
        
        let singupTap = UITapGestureRecognizer(target: self, action: Selector("toggleSignup:"))
        signupView.addGestureRecognizer(singupTap)
        
        let mixTap = UITapGestureRecognizer(target: self, action: Selector("toggleMix:"))
        mixView.addGestureRecognizer(mixTap)
        
        let listenTap = UITapGestureRecognizer(target: self, action: Selector("toggleListen:"))
        listenView.addGestureRecognizer(listenTap)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        markAsSeen(self, true)
    }
    
    @IBAction func actionLogout(sender: AnyObject) {
        navigationController?.popToRootViewControllerAnimated(true)
        markAsSeen(navigationController!.viewControllers.last as! UIViewController, false)
    }
}
