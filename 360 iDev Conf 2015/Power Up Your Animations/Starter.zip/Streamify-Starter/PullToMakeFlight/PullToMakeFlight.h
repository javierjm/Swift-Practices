//
//  PullToMakeFlight.h
//  PullToMakeFlight
//
//  Created by Anastasiya Gorban on 5/27/15.
//  Copyright (c) 2015 Yalantis. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PullToMakeFlight.
FOUNDATION_EXPORT double PullToMakeFlightVersionNumber;

//! Project version string for PullToMakeFlight.
FOUNDATION_EXPORT const unsigned char PullToMakeFlightVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PullToMakeFlight/PublicHeader.h>


